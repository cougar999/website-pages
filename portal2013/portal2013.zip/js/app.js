$(function(){
	$('#solution_slide').slides({
		preload: true,
		//play: 2500,
		pause: 1000,
		hoverPause: true
	});
});

$(document).ready(function(){
	/*$("#c3c").click(function(){
		var wd = $(window).outerWidth();
		$("#main").animate({
			"left":-wd
		}, function(){
			var h = $("#mainin").load('solution.html #main');
			$("main2").append(h);
		});
		return false;
	});*/
});
